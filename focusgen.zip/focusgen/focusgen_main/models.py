from django.db import models
from django.utils import timezone

class FocusSession(models.Model):
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(null=True, blank=True)
    duration = models.IntegerField(default=25)
    task_name = models.CharField(max_length=255, blank=True)
    focus_level = models.IntegerField(null=True, blank=True)
    reflection = models.TextField(blank=True)

    def __str__(self):
        return f"{self.task_name or 'Unnamed'} ({self.start_time.strftime('%b %d, %H:%M')})"
