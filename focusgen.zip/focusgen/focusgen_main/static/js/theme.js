// === FocusFlow Theme Toggle ===

const root = document.documentElement;
const toggleBtn = document.getElementById("themeToggle");

// Load saved theme
const savedTheme = localStorage.getItem("theme") || "light";
document.documentElement.setAttribute("data-theme", savedTheme);
toggleBtn.textContent = savedTheme === "dark" ? "🌙" : "🌞";

// Toggle logic
toggleBtn.addEventListener("click", () => {
  const currentTheme = root.getAttribute("data-theme");
  const newTheme = currentTheme === "dark" ? "light" : "dark";

  root.setAttribute("data-theme", newTheme);
  localStorage.setItem("theme", newTheme);

  toggleBtn.textContent = newTheme === "dark" ? "🌙" : "🌞";

  // Add a short transition for smooth theme switch
  root.classList.add("theme-transition");
  setTimeout(() => {
    root.classList.remove("theme-transition");
  }, 400);
});
