const circle = document.querySelector(".progress-ring__circle");
const total = 440;
let timeLeft = 25 * 60;
let timer;

function updateCircle() {
  const progress = (timeLeft / (25 * 60)) * total;
  circle.style.strokeDashoffset = total - progress;
}

start?.addEventListener("click", () => {
  fetch("/start/");
  start.style.display = "none";
  end.style.display = "inline-block";
  document.querySelector(".timer-card").classList.add("pulse");
  timer = setInterval(() => {
    timeLeft--;
    updateCircle();
    const m = String(Math.floor(timeLeft / 60)).padStart(2, "0");
    const s = String(timeLeft % 60).padStart(2, "0");
    time.textContent = `${m}:${s}`;
    if (timeLeft <= 0) {
      clearInterval(timer);
      modal.style.display = "flex";
    }
  }, 1000);
});

end?.addEventListener("click", () => {
  clearInterval(timer);
  modal.style.display = "flex";
});
const toggle = document.getElementById("themeToggle");
const html = document.documentElement;
if (localStorage.theme) html.dataset.theme = localStorage.theme;
toggle?.addEventListener("click", () => {
  html.dataset.theme = html.dataset.theme === "dark" ? "light" : "dark";
  localStorage.theme = html.dataset.theme;
  toggle.textContent = html.dataset.theme === "dark" ? "☀️" : "🌙";
});
