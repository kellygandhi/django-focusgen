from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('start/', views.start_session, name='start_session'),
    path('end/', views.end_session, name='end_session'),
]
