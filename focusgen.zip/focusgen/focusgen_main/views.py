from django.shortcuts import render, redirect
from django.utils import timezone
from datetime import timedelta
from .models import FocusSession

def home(request):
    sessions = FocusSession.objects.all().order_by('-start_time')[:10]

    # Weekly performance chart data
    week_ago = timezone.now() - timedelta(days=7)
    weekly_data = FocusSession.objects.filter(start_time__gte=week_ago)
    chart_data = [
        {"day": s.start_time.strftime("%a"), "focus": s.focus_level or 0}
        for s in weekly_data
    ]

    # 🧠 Streak calculation
    today = timezone.localdate()
    days = [today - timedelta(days=i) for i in range(6, -1, -1)]
    streak_days = []
    streak_count = 0
    last_day_with_session = None

    for day in reversed(days):
        has_session = FocusSession.objects.filter(start_time__date=day).exists()
        streak_days.append({"day": day.strftime("%a"), "active": has_session})
        if has_session:
            if not last_day_with_session or (last_day_with_session - day).days == 1:
                streak_count += 1
                last_day_with_session = day
            else:
                streak_count = 1
                last_day_with_session = day

    context = {
        "sessions": sessions,
        "chart_data": chart_data,
        "streak_days": streak_days,
        "streak_count": streak_count,
    }
    return render(request, "home.html", context)

def start_session(request):
    FocusSession.objects.create()
    return redirect('home')

def end_session(request):
    if request.method == 'POST':
        task = request.POST.get('task_name')
        focus = request.POST.get('focus_level')
        note = request.POST.get('reflection')

        session = FocusSession.objects.filter(end_time__isnull=True).last()
        if session:
            session.end_time = timezone.now()
            session.task_name = task
            session.focus_level = focus
            session.reflection = note
            session.save()
    return redirect('home')
